#d = z/sqrt(n)
#n=20
#10mg: ∆RT = 31.9 ms, z = 6.46, p < 0.0001)
d10= 6.46/sqrt(20)
print(d10)


#20mg: (∆RT = 47.0 ms, z = 9.33, p < 0.0001)
d20= 9.33/sqrt(20)
print(d20)


#30mg: (∆RT = 59.7 ms, z = 11.32, p < 0.0001) 
d30= 11.32/sqrt(20)
print(d30)